import zipfile
import pandas as pd
import os
import tempfile
from typing import List, Dict, Any, Tuple
import io

class BenefitCalculator:
    """
    Classe responsável por processar os dados de benefícios dos funcionários.
    """
    
    def __init__(self):
        # Configurações padrão para sindicatos
        self.sindicato_ajustes = {
            'SP': 50,
            'RJ': 70,
            'PR': 60,
            'RS': 80
        }
        
        # Critérios de inelegibilidade
        self.cargos_inelegiveis = ['Estagiário', 'Aprendiz', 'Diretor']
        self.status_inelegiveis = ['Afastado', 'Demitido']
        self.locais_inelegiveis = ['Exterior']
    
    def extract_zip_file(self, zip_file_bytes: bytes) -> List[pd.DataFrame]:
        """
        Extrai e lê todas as planilhas de um arquivo ZIP.
        
        Args:
            zip_file_bytes: Bytes do arquivo ZIP
            
        Returns:
            Lista de DataFrames contendo os dados das planilhas
        """
        dataframes = []
        
        with tempfile.TemporaryDirectory() as temp_dir:
            # Salva o arquivo ZIP temporariamente
            zip_path = os.path.join(temp_dir, 'uploaded.zip')
            with open(zip_path, 'wb') as f:
                f.write(zip_file_bytes)
            
            # Extrai o ZIP
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            
            # Lê todos os arquivos Excel/CSV extraídos
            for root, dirs, files in os.walk(temp_dir):
                for file in files:
                    if file.endswith(('.xlsx', '.xls', '.csv')):
                        file_path = os.path.join(root, file)
                        try:
                            if file.endswith('.csv'):
                                df = pd.read_csv(file_path)
                            else:
                                df = pd.read_excel(file_path)
                            
                            if not df.empty:
                                dataframes.append(df)
                        except Exception as e:
                            print(f"Erro ao ler arquivo {file}: {e}")
                            continue
        
        return dataframes
    
    def unify_dataframes(self, dataframes: List[pd.DataFrame]) -> pd.DataFrame:
        """
        Unifica múltiplos DataFrames em um único DataFrame.
        
        Args:
            dataframes: Lista de DataFrames para unificar
            
        Returns:
            DataFrame unificado
        """
        if not dataframes:
            return pd.DataFrame()
        
        # Padroniza os nomes das colunas
        standardized_dfs = []
        for df in dataframes:
            df_copy = df.copy()
            
            # Mapeia possíveis variações de nomes de colunas
            column_mapping = {
                'id_funcionario': 'ID_Funcionario',
                'idfuncionario': 'ID_Funcionario',
                'id': 'ID_Funcionario',
                'nome': 'Nome',
                'cargo': 'Cargo',
                'status': 'Status',
                'sindicato': 'Sindicato',
                'valor_beneficio_base': 'Valor_Beneficio_Base',
                'valorbeneficiobase': 'Valor_Beneficio_Base',
                'valor_base': 'Valor_Beneficio_Base',
                'data_admissao': 'Data_Admissao',
                'dataadmissao': 'Data_Admissao',
                'admissao': 'Data_Admissao',
                'data_demissao': 'Data_Demissao',
                'datademissao': 'Data_Demissao',
                'demissao': 'Data_Demissao'
            }
            
            # Renomeia as colunas (case-insensitive)
            df_copy.columns = [column_mapping.get(col.lower(), col) for col in df_copy.columns]
            
            standardized_dfs.append(df_copy)
        
        # Concatena todos os DataFrames
        unified_df = pd.concat(standardized_dfs, ignore_index=True)
        
        # Remove duplicatas baseadas no ID_Funcionario, se existir
        if 'ID_Funcionario' in unified_df.columns:
            unified_df = unified_df.drop_duplicates(subset=['ID_Funcionario'], keep='first')
        
        return unified_df
    
    def apply_eligibility_rules(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Aplica as regras de elegibilidade aos funcionários.
        
        Args:
            df: DataFrame com os dados dos funcionários
            
        Returns:
            DataFrame com colunas adicionais de elegibilidade
        """
        df_copy = df.copy()
        
        # Inicializa colunas de elegibilidade
        df_copy['Elegivel'] = 'Sim'
        df_copy['Motivo_Inelegibilidade'] = ''
        
        # Aplica regras de inelegibilidade
        for index, row in df_copy.iterrows():
            motivos = []
            
            # Verifica cargo
            if 'Cargo' in row and row['Cargo'] in self.cargos_inelegiveis:
                motivos.append(f"Cargo: {row['Cargo']}")
            
            # Verifica status
            if 'Status' in row and row['Status'] in self.status_inelegiveis:
                motivos.append(f"Status: {row['Status']}")
            
            # Verifica localização (sindicato)
            if 'Sindicato' in row and row['Sindicato'] in self.locais_inelegiveis:
                motivos.append(f"Localização: {row['Sindicato']}")
            
            if motivos:
                df_copy.at[index, 'Elegivel'] = 'Não'
                df_copy.at[index, 'Motivo_Inelegibilidade'] = '; '.join(motivos)
        
        return df_copy
    
    def calculate_benefits(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calcula os benefícios finais aplicando os ajustes por sindicato.
        
        Args:
            df: DataFrame com os dados dos funcionários elegíveis
            
        Returns:
            DataFrame com os valores de benefício calculados
        """
        df_copy = df.copy()
        
        # Inicializa colunas de cálculo
        df_copy['Ajuste_Sindicato'] = 0
        df_copy['Valor_Beneficio_Final'] = 0
        
        # Calcula apenas para funcionários elegíveis
        eligible_mask = df_copy['Elegivel'] == 'Sim'
        
        for index, row in df_copy[eligible_mask].iterrows():
            sindicato = row.get('Sindicato', '')
            valor_base = row.get('Valor_Beneficio_Base', 0)
            
            # Aplica ajuste por sindicato
            ajuste = self.sindicato_ajustes.get(sindicato, 0)
            valor_final = valor_base + ajuste
            
            df_copy.at[index, 'Ajuste_Sindicato'] = ajuste
            df_copy.at[index, 'Valor_Beneficio_Final'] = valor_final
        
        return df_copy
    
    def generate_summary(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Gera um resumo dos benefícios calculados.
        
        Args:
            df: DataFrame com os benefícios calculados
            
        Returns:
            Dicionário com o resumo dos resultados
        """
        eligible_df = df[df['Elegivel'] == 'Sim']
        
        summary = {
            'total_funcionarios': len(df),
            'funcionarios_elegiveis': len(eligible_df),
            'funcionarios_inelegiveis': len(df) - len(eligible_df),
            'total_beneficio_geral': eligible_df['Valor_Beneficio_Final'].sum(),
            'resumo_por_sindicato': {}
        }
        
        # Resumo por sindicato
        for sindicato in self.sindicato_ajustes.keys():
            sindicato_df = eligible_df[eligible_df['Sindicato'] == sindicato]
            summary['resumo_por_sindicato'][sindicato] = {
                'funcionarios': len(sindicato_df),
                'total_beneficio': sindicato_df['Valor_Beneficio_Final'].sum()
            }
        
        return summary
    
    def process_zip_file(self, zip_file_bytes: bytes) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        """
        Processa completamente um arquivo ZIP com dados de funcionários.
        
        Args:
            zip_file_bytes: Bytes do arquivo ZIP
            
        Returns:
            Tupla contendo (DataFrame processado, resumo dos resultados)
        """
        # Extrai e unifica os dados
        dataframes = self.extract_zip_file(zip_file_bytes)
        unified_df = self.unify_dataframes(dataframes)
        
        if unified_df.empty:
            return pd.DataFrame(), {'error': 'Nenhum dado válido encontrado no arquivo ZIP'}
        
        # Aplica regras de elegibilidade
        eligible_df = self.apply_eligibility_rules(unified_df)
        
        # Calcula benefícios
        final_df = self.calculate_benefits(eligible_df)
        
        # Gera resumo
        summary = self.generate_summary(final_df)
        
        return final_df, summary

