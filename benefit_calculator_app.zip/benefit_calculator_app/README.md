# Sistema de Cálculo de Benefícios

Uma aplicação web interativa desenvolvida com Streamlit para calcular benefícios de vale alimentação/refeição de funcionários.

## Funcionalidades

- 📁 Upload de arquivos ZIP contendo múltiplas planilhas de dados
- 🔍 Aplicação automática de regras de elegibilidade
- 💰 Cálculo de ajustes por sindicato (SP, RJ, PR, RS)
- 🤖 Análise inteligente com Google Gemini
- 📊 Visualização de resultados e métricas
- 💾 Download de relatórios em Excel e CSV

## Tecnologias Utilizadas

- **Frontend**: Streamlit
- **Backend**: Python
- **IA**: Google Gemini via LangChain
- **Processamento de Dados**: Pandas, OpenPyXL
- **Implantação**: Render.com

## Instalação Local

1. Clone o repositório
2. Crie um ambiente virtual:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   # ou
   venv\Scripts\activate  # Windows
   ```
3. Instale as dependências:
   ```bash
   pip install -r requirements.txt
   ```
4. Configure a variável de ambiente (opcional):
   ```bash
   export GOOGLE_API_KEY=sua_chave_api_aqui
   ```
5. Execute a aplicação:
   ```bash
   streamlit run app.py
   ```

## Uso

1. Acesse a aplicação no navegador
2. Faça o upload de um arquivo ZIP contendo planilhas Excel ou CSV
3. Configure a análise com IA (opcional)
4. Clique em "Processar Dados"
5. Visualize os resultados e faça download dos relatórios

## Critérios de Elegibilidade

Funcionários **inelegíveis** para benefícios:
- Estagiários
- Aprendizes
- Diretores
- Funcionários afastados
- Funcionários demitidos
- Funcionários no exterior

## Ajustes por Sindicato

- **SP**: R$ 50,00
- **RJ**: R$ 70,00
- **PR**: R$ 60,00
- **RS**: R$ 80,00

## Estrutura do Projeto

```
benefit_calculator_app/
├── app.py                 # Aplicação principal Streamlit
├── backend/
│   ├── data_processor.py  # Lógica de processamento de dados
│   └── gemini_integration.py  # Integração com Google Gemini
├── requirements.txt       # Dependências Python
├── render.yaml           # Configuração para Render.com
└── README.md             # Este arquivo
```

## Implantação

A aplicação está configurada para implantação automática no Render.com usando o arquivo `render.yaml`.

## Licença

Este projeto foi desenvolvido pela Manus AI.

