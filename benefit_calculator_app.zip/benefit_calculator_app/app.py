import streamlit as st
import pandas as pd
import io
import os
from datetime import datetime
from backend.data_processor import BenefitCalculator
from backend.gemini_integration import GeminiAnalyzer

# Configuração da página
st.set_page_config(
    page_title="Sistema de Cálculo de Benefícios",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS customizado
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #1f77b4;
    }
    .success-message {
        background-color: #d4edda;
        color: #155724;
        padding: 1rem;
        border-radius: 0.5rem;
        border: 1px solid #c3e6cb;
    }
    .error-message {
        background-color: #f8d7da;
        color: #721c24;
        padding: 1rem;
        border-radius: 0.5rem;
        border: 1px solid #f5c6cb;
    }
</style>
""", unsafe_allow_html=True)

def main():
    # Título principal
    st.markdown('<h1 class="main-header">💰 Sistema de Cálculo de Benefícios</h1>', unsafe_allow_html=True)
    
    # Barra lateral
    with st.sidebar:
        st.header("📋 Navegação")
        st.markdown("---")
        
        # Informações sobre o sistema
        st.subheader("ℹ️ Sobre o Sistema")
        st.write("""
        Este sistema processa dados de funcionários para calcular benefícios de vale alimentação/refeição.
        
        **Funcionalidades:**
        - Upload de arquivo ZIP com planilhas
        - Aplicação de regras de elegibilidade
        - Cálculo de ajustes por sindicato
        - Análise com IA (Gemini)
        - Geração de relatórios
        """)
        
        st.markdown("---")
        
        # Configurações opcionais
        st.subheader("⚙️ Configurações")
        use_gemini = st.checkbox("Usar análise com IA (Gemini)", value=True)
        
        if use_gemini:
            gemini_api_key = st.text_input(
                "Chave API do Gemini (opcional)",
                type="password",
                help="Se não fornecida, usará a variável de ambiente GOOGLE_API_KEY"
            )
        else:
            gemini_api_key = None
    
    # Área principal
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("📁 Upload de Arquivo")
        st.write("Faça o upload de um arquivo ZIP contendo as planilhas de dados dos funcionários.")
        
        uploaded_file = st.file_uploader(
            "Selecione o arquivo ZIP",
            type=['zip'],
            help="O arquivo deve conter planilhas Excel (.xlsx, .xls) ou CSV com dados dos funcionários"
        )
        
        # Botão de processamento
        process_button = st.button(
            "🚀 Processar Dados",
            disabled=uploaded_file is None,
            use_container_width=True
        )
    
    with col2:
        st.subheader("📊 Status")
        status_placeholder = st.empty()
        
        # Status inicial
        with status_placeholder.container():
            st.info("Aguardando upload do arquivo...")
    
    # Processamento dos dados
    if process_button and uploaded_file is not None:
        try:
            # Atualiza status
            with status_placeholder.container():
                st.warning("Processando arquivo...")
            
            # Lê o arquivo ZIP
            zip_bytes = uploaded_file.read()
            
            # Inicializa o calculador
            calculator = BenefitCalculator()
            
            # Processa os dados
            with st.spinner("Extraindo e processando dados..."):
                processed_df, summary = calculator.process_zip_file(zip_bytes)
            
            if 'error' in summary:
                st.error(f"Erro no processamento: {summary['error']}")
                return
            
            # Atualiza status para sucesso
            with status_placeholder.container():
                st.success("Processamento concluído!")
            
            # Armazena os resultados na sessão
            st.session_state['processed_df'] = processed_df
            st.session_state['summary'] = summary
            st.session_state['upload_time'] = datetime.now()
            
        except Exception as e:
            st.error(f"Erro durante o processamento: {str(e)}")
            return
    
    # Exibe resultados se disponíveis
    if 'processed_df' in st.session_state and 'summary' in st.session_state:
        display_results(
            st.session_state['processed_df'],
            st.session_state['summary'],
            use_gemini,
            gemini_api_key
        )

def display_results(df: pd.DataFrame, summary: dict, use_gemini: bool, gemini_api_key: str = None):
    """
    Exibe os resultados do processamento.
    """
    st.markdown("---")
    st.header("📈 Resultados do Cálculo de Benefícios")
    
    # Métricas principais
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Total de Funcionários",
            summary['total_funcionarios'],
            help="Número total de funcionários no arquivo"
        )
    
    with col2:
        st.metric(
            "Funcionários Elegíveis",
            summary['funcionarios_elegiveis'],
            help="Funcionários que atendem aos critérios de elegibilidade"
        )
    
    with col3:
        st.metric(
            "Funcionários Inelegíveis",
            summary['funcionarios_inelegiveis'],
            help="Funcionários que não atendem aos critérios"
        )
    
    with col4:
        st.metric(
            "Custo Total",
            f"R$ {summary['total_beneficio_geral']:,.2f}",
            help="Valor total dos benefícios para funcionários elegíveis"
        )
    
    # Resumo por sindicato
    st.subheader("📊 Resumo por Sindicato")
    
    sindicato_data = []
    for sindicato, data in summary['resumo_por_sindicato'].items():
        sindicato_data.append({
            'Sindicato': sindicato,
            'Funcionários': data['funcionarios'],
            'Total Benefício': f"R$ {data['total_beneficio']:,.2f}"
        })
    
    if sindicato_data:
        sindicato_df = pd.DataFrame(sindicato_data)
        st.dataframe(sindicato_df, use_container_width=True)
    
    # Tabela de funcionários elegíveis
    st.subheader("👥 Funcionários Elegíveis")
    
    eligible_df = df[df['Elegivel'] == 'Sim'].copy()
    if not eligible_df.empty:
        # Seleciona colunas relevantes para exibição
        display_columns = ['Nome', 'Cargo', 'Sindicato', 'Valor_Beneficio_Base', 'Ajuste_Sindicato', 'Valor_Beneficio_Final']
        display_df = eligible_df[display_columns].copy()
        
        # Formata valores monetários
        for col in ['Valor_Beneficio_Base', 'Ajuste_Sindicato', 'Valor_Beneficio_Final']:
            if col in display_df.columns:
                display_df[col] = display_df[col].apply(lambda x: f"R$ {x:,.2f}")
        
        st.dataframe(display_df, use_container_width=True)
    else:
        st.warning("Nenhum funcionário elegível encontrado.")
    
    # Funcionários inelegíveis
    ineligible_df = df[df['Elegivel'] == 'Não'].copy()
    if not ineligible_df.empty:
        with st.expander("❌ Funcionários Inelegíveis"):
            ineligible_display = ineligible_df[['Nome', 'Cargo', 'Status', 'Sindicato', 'Motivo_Inelegibilidade']].copy()
            st.dataframe(ineligible_display, use_container_width=True)
    
    # Análise com Gemini (se habilitada)
    if use_gemini:
        display_gemini_analysis(df, summary, gemini_api_key)
    
    # Seção de downloads
    display_download_section(df, summary)

def display_gemini_analysis(df: pd.DataFrame, summary: dict, api_key: str = None):
    """
    Exibe a análise gerada pelo Gemini.
    """
    st.subheader("🤖 Análise com IA (Gemini)")
    
    try:
        # Inicializa o analisador Gemini
        analyzer = GeminiAnalyzer(api_key)
        
        # Tabs para diferentes tipos de análise
        tab1, tab2, tab3 = st.tabs(["📊 Análise Detalhada", "📋 Resumo Executivo", "📖 Critérios de Elegibilidade"])
        
        with tab1:
            with st.spinner("Gerando análise detalhada..."):
                analysis = analyzer.analyze_benefit_data(summary, df)
                st.markdown(analysis)
        
        with tab2:
            with st.spinner("Gerando resumo executivo..."):
                executive_summary = analyzer.generate_executive_summary(summary)
                st.markdown(executive_summary)
        
        with tab3:
            with st.spinner("Explicando critérios de elegibilidade..."):
                criteria_explanation = analyzer.explain_eligibility_criteria()
                st.markdown(criteria_explanation)
    
    except Exception as e:
        st.error(f"Erro na análise com Gemini: {str(e)}")
        st.info("Verifique se a chave da API do Gemini está configurada corretamente.")

def display_download_section(df: pd.DataFrame, summary: dict):
    """
    Exibe a seção de downloads.
    """
    st.subheader("💾 Downloads")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Download Excel
        excel_buffer = io.BytesIO()
        with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Dados Processados', index=False)
            
            # Adiciona uma planilha de resumo
            summary_df = pd.DataFrame([
                ['Total de Funcionários', summary['total_funcionarios']],
                ['Funcionários Elegíveis', summary['funcionarios_elegiveis']],
                ['Funcionários Inelegíveis', summary['funcionarios_inelegiveis']],
                ['Custo Total dos Benefícios', f"R$ {summary['total_beneficio_geral']:,.2f}"]
            ], columns=['Métrica', 'Valor'])
            summary_df.to_excel(writer, sheet_name='Resumo', index=False)
        
        excel_buffer.seek(0)
        
        st.download_button(
            label="📊 Baixar Planilha Excel",
            data=excel_buffer.getvalue(),
            file_name=f"beneficios_calculados_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True
        )
    
    with col2:
        # Download CSV
        csv_buffer = io.StringIO()
        df.to_csv(csv_buffer, index=False)
        csv_data = csv_buffer.getvalue()
        
        st.download_button(
            label="📄 Baixar CSV",
            data=csv_data,
            file_name=f"beneficios_calculados_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv",
            use_container_width=True
        )

if __name__ == "__main__":
    main()

